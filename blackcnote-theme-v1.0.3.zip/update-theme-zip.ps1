# BlackCnote Theme ZIP Update Script
# Always zips the entire blackcnote folder from within the blackcnote directory

param(
    [string]$Version = "1.0.0"
)

$ThemeDir = Get-Location
$ThemeName = Split-Path $ThemeDir -Leaf

if ($ThemeName -ne "blackcnote") {
    Write-Host "❌ Error: Run this script from the blackcnote theme directory" -ForegroundColor Red
    exit 1
}

$ZipFileName = "blackcnote-theme-v$Version.zip"
$ZipPath = Join-Path $ThemeDir $ZipFileName

# Remove old zips
Get-ChildItem -Path $ThemeDir -Filter "*.zip" | Remove-Item -Force -ErrorAction SilentlyContinue

# Create the zip (excluding itself)
Compress-Archive -Path "$ThemeDir\*" -DestinationPath $ZipPath -Force

Write-Host "✅ Created $ZipFileName in $ThemeDir" -ForegroundColor Green

# Optionally add to git
git add $ZipFileName
git commit -m "Update theme ZIP package v$Version"
git push origin main
Write-Host "✅ ZIP package added to Git repository" -ForegroundColor Green
